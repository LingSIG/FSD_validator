# LaTeX2HTML 97.1 (release) (July 13th, 1997)
# Associate images original text with physical files.


$key = q/{_inline}rangle{_inline}MSF=2.5;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="10" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="img2.gif"
 ALT="$\rangle$">|; 

$key = q/{_inline}langle{_inline}MSF=2.5;AAT;/;
$cached_env_img{$key} = q|<IMG WIDTH="10" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="img1.gif"
 ALT="$\langle$">|; 

1;

